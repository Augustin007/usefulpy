'''This code has not been started'''

import warnings
warnings.warn(Warning(__doc__))
