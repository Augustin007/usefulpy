#Primary importations
from functools import reduce as _reduce
from math import *
del degrees, radians, log10
import warnings
from statistics import Decimal as num, Fraction as fraction
from usefulpy import validation

def makefraction(numer, denom = 1):
    '''Make a valid fraction type out of a float type'''
    numer = validation.tryint(round(float(numer), 15))
    denom = validation.tryint(round(float(denom), 15))
    while not (validation.is_integer(numer) and validation.is_integer(denom)):
        denom *= 10
        numer *= 10
    return fraction(int(numer), int(denom))

def rt(nth, num, /):
    '''return nth root of num'''
    return validation.tryint(num**(1/nth))

def irt(nth, num, /):
    '''return integer nth root of num'''
    return int(rt(nth, num))

_log = log
ln = lambda x: _log(x)
def log(x, base = 10, /): return _log(x, base)

angle = 'rad'
def radians():
    global angle
    angle = 'rad'
def degrees():
    global angle
    angle = 'deg'
_acos=acos
def acos(x, /):
    ans = _acos(x)
    if angle == 'deg':
        return RadiansToDegrees(ans)
    return ans
_acosh=acosh
def acosh(x, /):
    ans = _acosh(x)
    if angle == 'deg':
        return RadiansToDegrees(ans)
    return ans
_asin=asin
def asin(x, /):
    ans = _asin(x)
    if angle == 'deg':
        return RadiansToDegrees(ans)
    return ans
_asinh=asinh
def asinh(x, /):
    ans = _asinh(x)
    if angle == 'deg':
        return RadiansToDegrees(ans)
    return ans
_atan=atan
def atan(x, /):
    ans = _atan(x)
    if angle == 'deg':
        return RadiansToDegrees(ans)
    return ans
_atan2=atan2
def atan2(x, /):
    ans = _atan2(x)
    if angle == 'deg':
        return RadiansToDegrees(ans)
    return ans
_atanh=atanh
def atanh(x, /):
    ans = _atanh(x)
    if angle == 'deg':
        return RadiansToDegrees(ans)
    return ans
_cos=cos
def cos(x, /):
    if angle == 'deg':
        x = DegreesToRadians(x)
    return _cos(x)
_cosh=cosh
def cosh(x, /):
    if angle == 'deg':
        x = DegreesToRadians(x)
    return _cosh(x)
_sin=sin
def sin(x, /):
    if angle == 'deg':
        x = DegreesToRadians(x)
    return _sin(x)
_sinh=sinh
def sinh(x, /):
    if angle == 'deg':
        x = DegreesToRadians(x)
    return _sinh(x)
_tan=tan
def tan(x, /):
    if angle == 'deg':
        x = DegreesToRadians(x)
    return _tan(x)
_tanh=tanh
def tanh(x, /):
    if angle == 'deg':
        x = DegreesToRadians(x)
    return _tanh(x)

cbrt = lambda x: rt(3, x)

icbrt = lambda x: irt(3, x)

def summation(start, finish, function = lambda x: x):
    '''Σ'''
    return _reduce((lambda x, y: x+function(y)), range(start, finish+1))
Σ = Sigma = summation #Summation is usually noted with a capital greek Sigma

pi = π = pi # π, ratio of diameter to circumference in circle
tau = τ = tau # τ, ratio of diameter to circumference in circle
e = e #e, number where f(x)=e^x, its derivative, f'(x) also equals e^x
Phi = Φ = (1+sqrt(5))/2 #1/(1+1/(1+1/(1+1/(1+1/(1+1/(1+1/(1+1/(1+1/(...)))))))))
#also (a+a*Φ)/a*Φ = a/a*Φ, golden ratio
phi = φ = (1-sqrt(5))/2 #another solution for Φ, signified by lowecase phi
rho = ρ = cbrt((9+sqrt(69))/18)+cbrt((9-sqrt(69))/18) #ρ**3 = ρ+1
sigma = σ = 1+sqrt(2) #2+1/(2+1/(2+1/(2+1/(2+1/(2+1/(2+1/(2+1/(2+1/(...)))))))))
#Called silver ratio
lsigma = ς = 1-sqrt(2)#Alternate solution for sigma, signified with an alternate
#writing of sigma
kappa = κ = (3+sqrt(13))/2 #Bronze ratio, 3+1/(3+1/(3+1/(3+1/(3+1/(...)))))
psi = ψ = (1+(cbrt((29+3*sqrt(93))/2))+(cbrt((29-3*sqrt(93))/2)))/3
#ψ, supergolden ratio x**3 = x**2+1
#all the numbers I could think of...
