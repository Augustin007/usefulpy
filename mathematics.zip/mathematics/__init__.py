'''
File: mathematics.py
Version: 1.2.1
Author: Austin Garcia

Several mathematical functions plopped together.

LICENSE: See license file.

PLATFORMS:
This program imports the python built-ins functools, math, warnings and
statistics as well as my validation... should work on any python platform
where these are available.

INSTALLATION:
Put this file where Python can see it.

RELEASE NOTES:
1
 1.1
  Version 1.1.1:
   mathematics.py contains many mathematical functions.
  Version 1.1.2:
   An updated description and various bug fixes. Cleaner looking code with more
   comments.
  Version 1.1.3:
   Some small bug fixes
   Raises warnings at unfinished sections
 1.2
  Version 1.2.1
   Separated into a folder of its own

'''
try:
    from PrimeComposite import *
    from nmath import *
    from triangles import *
    from basenum import *
    from eq import *
    from algebraicsolver import *
    from quaternion import *
except:
    from usefulpy.mathematics.PrimeComposite import *
    from usefulpy.mathematics.nmath import *
    from usefulpy.mathematics.triangles import *
    from usefulpy.mathematics.basenum import *
    from usefulpy.mathematics.eq import *
    from usefulpy.mathematics.algebraicsolver import *
    from usefulpy.mathematics.quaternion import *
